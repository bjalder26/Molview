Clazz.declarePackage ("javajs");
