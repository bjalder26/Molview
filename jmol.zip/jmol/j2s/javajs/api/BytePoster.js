Clazz.declarePackage ("javajs.api");
Clazz.declareInterface (javajs.api, "BytePoster");
