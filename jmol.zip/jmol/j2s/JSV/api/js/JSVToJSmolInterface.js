Clazz.declarePackage ("JSV.api.js");
Clazz.load (["javajs.api.js.J2SObjectInterface"], "JSV.api.js.JSVToJSmolInterface", null, function () {
Clazz.declareInterface (JSV.api.js, "JSVToJSmolInterface", javajs.api.js.J2SObjectInterface);
});
