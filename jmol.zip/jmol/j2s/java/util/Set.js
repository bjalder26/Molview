Clazz.load(["java.util.Collection"],"java.util.Set",null,function(){
Clazz.declareInterface(java.util,"Set",java.util.Collection);
});
