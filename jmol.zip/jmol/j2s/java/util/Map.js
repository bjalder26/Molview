Clazz.declareInterface(java.util,"Map");
Clazz.declareInterface(java.util.Map,"Entry");
