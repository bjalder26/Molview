Clazz.declareInterface(java.util,"Observer");
