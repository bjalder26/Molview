Clazz.load(["java.util.NoSuchElementException"],"java.util.InputMismatchException",null,function(){
c$=Clazz.declareType(java.util,"InputMismatchException",java.util.NoSuchElementException,java.io.Serializable);
});
