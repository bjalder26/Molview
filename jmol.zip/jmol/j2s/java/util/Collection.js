Clazz.declareInterface(java.util,"Collection",Iterable);
