Clazz.declareInterface(java.io,"Externalizable",java.io.Serializable);
