Clazz.declareInterface(java.io,"Serializable");
