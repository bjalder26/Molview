Clazz.declareInterface(java.io,"Closeable");
