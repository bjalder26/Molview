Clazz.load(["java.io.ObjectStreamException"],"java.io.OptionalDataException",null,function(){
c$=Clazz.decorateAsClass(function(){
this.eof=false;
this.length=0;
Clazz.instantialize(this,arguments);
},java.io,"OptionalDataException",java.io.ObjectStreamException);
});
