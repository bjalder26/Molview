Clazz.load(["java.lang.LinkageError"],"java.lang.NoClassDefFoundError",null,function(){
c$=Clazz.declareType(java.lang,"NoClassDefFoundError",LinkageError);
});
