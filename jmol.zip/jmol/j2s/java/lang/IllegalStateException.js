Clazz.load(["java.lang.RuntimeException"],"java.lang.IllegalStateException",null,function(){
c$=Clazz.declareType(java.lang,"IllegalStateException",RuntimeException);
Clazz.makeConstructor(c$,
function(cause){
Clazz.superConstructor(this,IllegalStateException,[(cause==null?null:cause.toString()),cause]);
},"Throwable");
});
