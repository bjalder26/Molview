Clazz.load(["java.lang.LinkageError"],"java.lang.VerifyError",null,function(){
c$=Clazz.declareType(java.lang,"VerifyError",LinkageError);
});
