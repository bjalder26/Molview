Clazz.load(["java.lang.Throwable"],"java.lang.Exception",null,function(){
c$=Clazz.declareType(java.lang,"Exception",Throwable);
});
