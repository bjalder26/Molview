Clazz.load(["java.lang.Exception"],"java.lang.NoSuchFieldException",null,function(){
c$=Clazz.declareType(java.lang,"NoSuchFieldException",Exception);
});
