Clazz.load(["java.security.BasicPermission"],"java.lang.reflect.ReflectPermission",null,function(){
c$=Clazz.declareType(java.lang.reflect,"ReflectPermission",java.security.BasicPermission);
});
