Clazz.declareInterface(java.lang.reflect,"AnnotatedElement");
