Clazz.load(["java.lang.IndexOutOfBoundsException"],"java.lang.StringIndexOutOfBoundsException",null,function(){
c$=Clazz.declareType(java.lang,"StringIndexOutOfBoundsException",IndexOutOfBoundsException);
Clazz.makeConstructor(c$,
function(index){
Clazz.superConstructor(this,StringIndexOutOfBoundsException,["String index out of range: "+index]);
},"~N");
});
